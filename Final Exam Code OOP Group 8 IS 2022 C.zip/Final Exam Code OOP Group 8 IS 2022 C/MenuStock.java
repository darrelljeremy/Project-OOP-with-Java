import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

// Mendeklarasikan kelas MenuStock untuk mengelola stok menu di restoran
public class MenuStock {
    // Menyimpan stok dari setiap item menu
    private HashMap<String, Integer> stock; 
    // Terdapat variabel untuk menyimpan stok saat ini
    public static int currentStock; 

    // Terdapat konstruktor untuk menginisialisasi objek MenuStock
    public MenuStock() {
        // Menginisialisasi HashMap untuk menyimpan stok
        this.stock = new HashMap<>(); 
        // Menginisialisasi stok untuk berbagai item menu
        initializeStock(); 
        // Menginisialisasi stok sekarang berdasar nilai stok awal
        updateCurrentStock(); 
    }

    // Terdapat method untuk menginisialisasi stok untuk berbagai item menu
    private void initializeStock() {
        // Menambahkan nilai stok awal untuk berbagai item menu
        stock.put("Caesar Salad", 2);
        stock.put("Mozzarella Sticks", 4);
        stock.put("Bruschetta", 2);
        stock.put("Shrimp Cocktail", 12);
        stock.put("Meat Risoles", 20);

        stock.put("Steak",5);
        stock.put("Spaghetti Bolognese",10);
        stock.put("Steak",5);
        stock.put("Chicken Parmesan", 4);
        stock.put("Grilled Salmon", 3);
        stock.put("Ribs", 2);
        stock.put("Pizza", 5);
        stock.put("Burger", 6);

        stock.put("Chocolate Cake", 3);
        stock.put("Tiramisu", 4);
        stock.put("Cheesecake", 5);
        stock.put("Ice Cream Sundae", 6);

        stock.put("Orange Juice", 10);
        stock.put("Apple Juice", 8);
        stock.put("Avocado Juice", 7);
        stock.put("Iced Tea", 12);
        stock.put("Coffee", 15);

       
    }

    // Terdapat method untuk memperbarui stok saat ini dengan menjumlahkan semua nilai stok
    private void updateCurrentStock() {
        currentStock = 0; // Atur ulang stok saat ini
        // Mengiterasi setiap nilai stok dan tambahkan ke stok saat ini
        for (int stockCount : stock.values()) {
            currentStock += stockCount;
        }
    }

    // Terdapat method untuk memeriksa apakah suatu item menu tertentu ada dalam stok
    public boolean checkStock(String menuName) {
        // Memeriksa apakah menuName ada dalam stok dan jumlahnya lebih dari 0
        return stock.containsKey(menuName) && stock.get(menuName) > 0;
    }

    // Terdapat method untuk meningkatkan jumlah stok untuk sebuah item menu
    public void increaseStock(String menuName) {
        // Memeriksa apakah menuName ada dalam stok
        if (stock.containsKey(menuName)) {
            // Menambahkan jumlah stok
            stock.put(menuName, stock.get(menuName) + 1); 
            // Memperbaharui stok yang tersedia sekarang
            updateCurrentStock();
            // Mencetak pesan sukses
            System.out.println("Stok " + menuName + " bertambah 1."); 
            System.out.println("");
        } else {
            // Cetak output berupa pesankesalahan jika menuName tidak ditemukan dalam stok
            System.out.println("Item menu " + menuName + " tidak ditemukan.");
            System.out.println("");
        }
    }

// Terdapat method untuk mengurangi jumlah stok untuk sebuah item menu yang dipesan pelanggan
public void decreaseStock(String menuName, int quantity) {
    // Memeriksa apakah menuName ada dalam stok dan jumlahnya lebih dari atau sama dengan jumlah yang dipesan
    if (stock.containsKey(menuName) && stock.get(menuName) >= quantity) {
        stock.put(menuName, stock.get(menuName) - quantity); // Mengurangi jumlah stok sesuai dengan jumlah yang dipesan
        updateCurrentStock(); // Memperbarui stok saat ini
        System.out.println("Stok " + menuName + " berkurang " + quantity + "."); // Cetak pesan sukses
        System.out.println("");
    } else if (stock.containsKey(menuName) && stock.get(menuName) < quantity) {
        // Cetak output berupa pesan kesalahan jika stok tidak mencukupi
        System.out.println("Maaf, stok " + menuName + " tidak mencukupi.");
        System.out.println("");
    } else {
        // Cetak output berupa pesan kesalahan jika menuName tidak ditemukan dalam stok
        System.out.println("Item menu " + menuName + " tidak ditemukan.");
        System.out.println("");
    }
}

// Terdapat method untuk menangani pesanan makanan
public void handleOrderFood(Scanner scan, ArrayList<Pesanan> pesananList) {
        // Meminta pelanggan memasukkan nama makanan
        System.out.print("Masukkan Nama Makanan : ");
        String namaMakanan = scan.nextLine();

        if (checkStock(namaMakanan)) {
            // Meminta pelanggan memasukkan harga makanan
            System.out.print("Masukkan Harga Makanan : ");
            double hargaMakanan = scan.nextDouble();
    
            // Meminta pelanggan untuk memasukkan jumlah makanan yang ingin dipesan
            System.out.print("Masukkan Jumlah yang ingin dipesan: ");
            int jumlahMakanan = scan.nextInt();
            scan.nextLine();

            // Menambahkan pesanan baru ke list pesanan
            pesananList.add(new Pesanan(namaMakanan, hargaMakanan, jumlahMakanan));
            
            // Mengurangi stok makanan yang dipesan
            decreaseStock(namaMakanan, jumlahMakanan);

            // Akan keluar output bahwa pesanan berhasil ditambahkan
            System.out.println("Pesanan berhasil ditambahkan.");
        } else {
            // Akan keluar output bahwa makanan tidak tersedia
            System.out.println("Maaf, makanan tidak tersedia.");
        }
    }
}