// Mendeklarasikan kelas Appetizer (subclass) yaitu urunan dari kelas Menu
public class Appettizer extends Menu{

    //Membuat konstruktor dengan variabel String nama, String harga, double rating, String type, String isFavorite
    public Appettizer(String nama, String harga, double rating, String type, String isFavorite) {
        super(nama, harga, rating, type, isFavorite);
    }

    // Dikarenakan adanya kelas abstract Menu, maka seluruh kelas turunan harus menggunakan method displayMenuu()

    // @Override adalah sebuah anotasi yang digunakan untuk menandai bahwa sebuah metode dalam suatu kelas 
    //merupakan override dari metode yang sama dalam kelas induknya (superclass)

    @Override
    // Menampilkan menu dan menggunakan Getter agar mendapat nilai dari atribut tersebut
    public void displayMenuu(){
        System.out.println("Foods Name    : " + getName());
        System.out.println("Foods Price   : " + getHarga());
        System.out.println("Foods Rating  : " + getRating());
        System.out.println("Foods Type    : " + getType());
        System.out.println("Fav's Menu    : " + getIsfavorite());
    }

    // displayMenuu() di dalam kelas Appettizer merupakan method untuk mengeprint semua menu Appetizer.
    // dan juga merupakan sebuah implementasi Polymorfism dimana nama methodnya sama, namun outputnya berbeda.

    
}