// Mendeklarasikan kelas MainCourse yang merupakan turunan dari kelas Menu 
public class MainCourse extends Menu {

    // Terdapat konstruktor dengan parameter nama, harga, rating, jenis dan apakah menu tersebut termasuk menu favorit atau tidak*/
    public MainCourse(String nama, String harga, double rating, String type, String isFavorite) {

        // Menginialisasi properti yang diwarisi dari kelas "Menu"
        super(nama, harga, rating, type, isFavorite);
    }

    // Dikarenakan adanya kelas abstract Menu, maka seluruh kelas turunan harus menggunakan method displayMenuu()

    // @Override adalah sebuah annotation yang digunakan untuk menandai bahwa sebuah metode dalam suatu kelas 
    // Merupakan override dari metode yang sama dalam kelas induknya (superclass)

    @Override
    // Menampilkan informasi spesifik mengenai makanan utama atau Main Course yang tersedia
    public void displayMenuu(){
        System.out.println("Foods Name    : " + getName());
        System.out.println("Foods Price   : " + getHarga());
        System.out.println("Foods Rating  : " + getRating());
        System.out.println("Foods Type    : " + getType());
        System.out.println("Fav's Menu    : " + getIsfavorite());
    } 
    // displayMenuu() di dalam kelas ainourse merupakan method untuk mengeprint semua menu Maincourse
    // danjuga merupakan sebuah implementasi Polymorfism dimana nama methodnya sama, namun outputnya berbeda
}