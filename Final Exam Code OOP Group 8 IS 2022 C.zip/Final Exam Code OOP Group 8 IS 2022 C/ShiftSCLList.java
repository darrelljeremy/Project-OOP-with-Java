// Mendeklarasikan kelas ShiftSCLList
public class ShiftSCLList {
    // Terdiri atas node privat saat ini
    private Node current; 

    // Terdapat kelas privat Node untuk single circular linked list
    private class Node {
        // Terdiri atas data berupa objek ShiftKoki
        ShiftKoki data; 
        // Terdiri referensi ke node selanjutnya
        Node next; 

        // Terdapat konstruktor untuk Node
        public Node(ShiftKoki data) {
            this.data = data;
            this.next = null; 
        }
    }

    private Node head; 
    private int size; 

    // Terdapat konstruktor untuk ShiftSCLList
    public ShiftSCLList() {
        // Menginisialisasi head sebagai null
        head = null; 
        // Menginisialisasi ukuran awal list yaitu 0
        size = 0; 
    }

    // Terdapat method untuk memeriksa apakah list kosong
    public boolean isEmpty() {
        return size == 0;
    }

    // Terdapat method untuk menambahkan shift ke dalam list
    public void addShift(ShiftKoki shift) {
        Node newNode = new Node(shift);
        if (isEmpty()) {
            head = newNode;
            newNode.next = head; 
            // Mengatur current ke head yang baru ditambahkan
            current = head; 
        } else {
            Node temp = head;
            while (temp.next != head) {
                temp = temp.next;
            }
            temp.next = newNode;
            newNode.next = head; 
        }
        size++;
    }

    // Terdapat method untuk menampilkan informasi shift saat ini
    public void displayCurrentShift() {
        // Menampilkan informasi shift koki
        if (current != null) {
            current.data.viewShiftKoki(); 
        } else {
            System.out.println("Shift not available.");
        }
    }

    // Terdapat method untuk mendapatkan shift berikutnya
    public ShiftKoki getNext(ShiftKoki shift) {
        if (isEmpty()) {
            return null;
        }

        Node current = head;
        do {
            if (current.data.equals(shift)) {
                return current.next.data;
            }
            current = current.next;
        } while (current != head);

        // Jika shift yang diberikan tidak ditemukan
        return null;
    }

    // Terdapat method untuk mendapatkan ukuran list
    public int size() {
        return size;
    }

    // Terdapat method untuk berpindah ke shift berikutnya
    public void next() {
        if (current != null) {
            current = current.next;
        } else {
            current = head; // Jika current null, set ke head node
        }
    }

    // Terdapat method publik untuk mengatur node saat ini
    public void setCurrent(Node node) {
        current = node;
    }

    // Terdapat method publik untuk mengatur node kepala
    public void setHead(Node node) {
        head = node;
    }
}