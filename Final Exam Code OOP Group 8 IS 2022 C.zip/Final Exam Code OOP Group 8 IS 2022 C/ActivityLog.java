// Mengimpor kelas Scanner sehingga bisa digunakan
import java.util.*;

/*Mendeklarasikan kelas ActivityLog dimana kelas ini merupakan inti dari sistem log aktivitas yang berisi operasi-operasi untuk
menambahkan entri baru ke log,mencetak entri log saat ini, serta melihat entri log
sebelumnya dan berikutnya. */

class ActivityLog {

/*Kelas ini merupakan kelas dalam yang bertanggung jawab untuk merepresentasikan 
entri tunggal dalam log. Setiap entri memiliki atribut seperti hari, jumlah pelanggan, 
pendapatan, serta referensi ke entri log sebelumnya dan berikutnya. */
    private static class LogNode {
        int day;
        int customers;
        double revenue;
        LogNode next;
        LogNode prev;

/*Baris ini mendefinisikan konstruktor untuk LogNode yang akan digunakan untuk membuat 
objek LogNode baru dengan nilai-nilai yang diberikan. */
        LogNode(int day, int customers, double revenue) {
            this.day = day;
            this.customers = customers;
            this.revenue = revenue;
        }
    }

    // Referensi menuju ke node pertama dalam daftar terhubung (log paling baru)
    private LogNode head;

    // Referensi menuju ke node terakhir dalam daftar terhubung (log paling lama)
    private LogNode tail;

    // Referensi menuju ke node yang sedang dipilih saat ini
    private LogNode current;

/*Baris ini menginisialisasi atribut-atribut head, tail, dan current menjadi null. */
    public ActivityLog() {
        head = null;
        tail = null;
        current = null;
/*Baris ini membuat objek dari kelas Random yang akan digunakan untuk menghasilkan angka acak.
Dan memulai loop untuk membuat entri log untuk 7 hari terakhir,Baris ini menghasilkan jumlah 
pelanggan secara acak antara 1 dan 50 serta menghasilkan pendapatan secara acak antara 0 dan 1000.
 */
        Random random = new Random();
        for (int i = 0; i <= 7; i++) {
            int customers = random.nextInt(50) + 1; // Jumlah pelanggan antara 1 dan 50
            double revenue = random.nextInt(1000) * 10; // Pendapatan antara 0 dan 1000

/*Baris ini memanggil metode addLog() untuk menambahkan entri log baru dengan
 nilai-nilai yang dihasilkan secara acak. */
            addLog(i, customers, revenue);
        }
        current = tail; 
    }

/*Terdapat method addLog(int day, int customers, double revenue) bertanggung jawab untuk menambahkan entri baru 
ke log aktivitas. Saat metode ini dipanggil, sebuah objek LogNode baru dibuat dengan menggunakan nilai-nilai
yang diberikan sebagai argumen. Selanjutnya, metode ini melakukan pengujian kondisi untuk memastikan apakah 
log sudah kosong. Jika log masih kosong, entri baru ditetapkan sebagai head dan tail dari linked list log.
 Namun, jika log telah berisi entri sebelumnya, entri baru akan dimasukkan di awal log dan referensi head
 diperbarui untuk menunjuk ke entri baru tersebut. Dengan demikian, metode ini memastikan bahwa entri baru 
selalu ditambahkan di awal log untuk mempertahankan urutan kronologis, sehingga entri terbaru selalu menjadi 
yang paling atas. */
    public void addLog(int day, int customers, double revenue) {
        LogNode newNode = new LogNode(day, customers, revenue);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }
    }
/*Terdapat method printCurrentLog() berfungsi untuk mencetak detail dari entri log yang sedang dipilih saat ini. Pertama, 
metode melakukan pemeriksaan untuk memastikan bahwa terdapat entri log saat ini yang dipilih. Jika ada entri 
log yang tersedia, maka detail seperti jumlah pelanggan, pendapatan, dan hari akan dicetak. Namun, jika tidak 
ada entri log yang tersedia, maka pesan "Log kosong" akan dicetak untuk memberi tahu pengguna bahwa log tidak 
berisi entri apapun pada saat itu. Dengan demikian, metode ini membantu untuk memberikan informasi yang relevan 
kepada pengguna terkait dengan aktivitas restoran pada saat itu. */
    public void printCurrentLog() {
        if (current != null) {
            System.out.println("Log" + (current.day == 0 ? " Hari ini" : " - " + current.day + " hari yang lalu") + ":");
            System.out.println("Jumlah pelanggan : " + current.customers);
            System.out.println("Pendapatan: Rp " + current.revenue);
            System.out.println("======================================");
        } else {
            System.out.println("Log kosong.");
        }
    }
/*Method nextLog() berfungsi untuk memindahkan referensi saat ini ke entri log berikutnya dalam urutan kronologis. 
Pertama-tama, metode melakukan pengujian kondisi untuk memeriksa apakah ada entri log berikutnya yang tersedia 
setelah entri saat ini. Jika ada, referensi current dipindahkan ke entri log berikutnya, dan detail dari entri 
log tersebut dicetak untuk memberikan informasi kepada pengguna. Namun, jika tidak ada entri log berikutnya yang 
tersedia, maka pesan "Belum ada data untuk hari esok" akan dicetak untuk memberi tahu pengguna bahwa tidak ada entri 
log yang tersedia untuk hari berikutnya. Dengan demikian, metode ini memungkinkan pengguna untuk melihat aktivitas
 restoran yang terjadi pada hari-hari yang berurutan setelah entri saat ini. */
    public void nextLog() {
        if (current != null && current.next != null) {
            current = current.next;
            printCurrentLog();
        } else {
            System.out.println("Belum ada data untuk hari esok.");
        }
    }
/*Method prevLog() berfungsi untuk memindahkan referensi saat ini ke entri log sebelumnya dalam urutan kronologis.
Pertama, dilakukan pengujian kondisi untuk memeriksa apakah terdapat entri log sebelumnya yang tersedia sebelum entri 
saat ini. Jika ada, referensi current dipindahkan ke entri log sebelumnya, dan detail dari entri log tersebut dicetak.
Namun, jika tidak ada entri log sebelumnya yang tersedia, maka pesan "Anda sudah mencapai batas aktivitas restoran mingguan"
akan dicetak. Dengan demikian, metode ini memungkinkan pengguna untuk melihat aktivitas restoran pada hari-hari sebelumnya
dalam periode waktu yang telah direkam dalam log. */
    public void prevLog() {
        if (current != null && current.prev != null) {
            current = current.prev;
            printCurrentLog();
        } else {
            System.out.println("Anda sudah mencapai batas aktivitas restoran mingguan.");
        }
    }
}