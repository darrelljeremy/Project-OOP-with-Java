//  Mendeklarasikan dan mengimplementasikan serve yang menyiapkan makanan kepada customer diikuti dengan parameter nama menu yang nantinya dipesan
public interface Iservefood {
    // Mendeklarasikan method prepare yang menerima parameter nama menu
    public void serve (String menuName);
}