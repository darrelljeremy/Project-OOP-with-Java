// Mendeklarasikan kelas ShiftKoki yang merupakan subclass dari kelas Koki
public class ShiftKoki extends Koki {
    // Terdiri atas atribut privat untuk menyimpan waktu shift
    private String shiftWaktu;

    // Terdapat konstructor untuk menginisialisasi objek ShiftKoki
    public ShiftKoki(String name, String position, String speciality, int experience, boolean isCertified,
                     MenuStock menuStock, String shiftWaktu) {
        // Memanggil constructor superclass (Koki)
        super(name, position, speciality, experience, isCertified, menuStock);
        // Menginisialisasi atribut shiftWaktu
        this.shiftWaktu = shiftWaktu;
    }

    // Terdapat method untuk menampilkan nama, posisi, keahlian, dan waktu shift dari setiap Koki
    public void viewShiftKoki() {
        System.out.println("--------------------------");
        System.out.println("       Koki Shifts        ");
        System.out.println("--------------------------");
        // Menampilkan informasi tentang koki
        System.out.println("Name: " + getName()); // Menampilkan nama
        System.out.println("Position: " + getPosition()); // Menampilkan posisi
        System.out.println("Speciality: " + getSpeciality()); // Menampilkan keahlian
        System.out.println("Shift Time: " + getShiftWaktu()); // Menampilkan waktu shift
        System.out.println("_");
    }

    // Menggunakan getter untuk atribut shiftWaktu
    public String getShiftWaktu() {
        return shiftWaktu;
    }
}