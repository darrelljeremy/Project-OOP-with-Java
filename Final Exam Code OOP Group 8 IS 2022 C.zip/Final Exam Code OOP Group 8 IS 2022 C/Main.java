import java.util.*;

// Mendeklarasikan kelas Main
public class Main {
    public static void main(String[] args) {
        // Mendeklarasikan kelas Scanner dengan nama variabel 'scan'
        Scanner scan = new Scanner(System.in);

        // Membuat ArrayList untuk menyimpan objek-objek Pesanan
        ArrayList<Pesanan> pesananList = new ArrayList<>();

        // Membuat objek Table
        Table table = new Table();

        // Membuat beberapa objek MenuCDLList untuk berbagai jenis menu
        MenuCDLList menuListAp = new MenuCDLList();
        MenuCDLList menuListM = new MenuCDLList();
        MenuCDLList menuListDs = new MenuCDLList();
        MenuCDLList menuListDr = new MenuCDLList();

        // Membuat objek ShiftSCLList untuk daftar shift koki
        ShiftSCLList shiftListKoki = new ShiftSCLList();

        // Membuat objek ActivityLog untuk menyimpan log aktivitas
        ActivityLog activityLog = new ActivityLog();

        // Membuat sampel restoran dengan tabel
        table.createSampleRestaurants(); 

        // Menginisialisasi objek Appetizer
        Appettizer appettizer1 = new Appettizer("Caesar Salad", "Rp.20.000", 4.2, "Appettizer", "Yes");
        Appettizer appettizer2 = new Appettizer("Mozzarella Sticks", "R0.17.000", 4.3, "Appettizer", "Yes");
        Appettizer appettizer3 = new Appettizer("Bruschetta", "Rp.18.000", 3.2, "Appettizer", "No");
        Appettizer appettizer4 = new Appettizer("Shrimp Cocktail", "Rp.28.000", 3.4, "Appettizer", "No");
        Appettizer appettizer5 = new Appettizer("Meat Risoles", "Rp.5.000", 4.3, "Appettizer", "Yes");

        // Menginisialisasi objek Main Course
        MainCourse mainCourse1 = new MainCourse("Steak", "Rp.120.000", 4.5, "Main Course", "Yes");
        MainCourse mainCourse2 = new MainCourse("Spaghetti Bolognese", "Rp.55.000", 3.4, "Main Course", "No");
        MainCourse mainCourse3 = new MainCourse("Chicken Parmesan", "Rp.45.000", 4.4, "Main Course", "Yes");
        MainCourse mainCourse4 = new MainCourse("Grilled Salmon", "Rp.85.000", 3.6, "Main Course", "No");
        MainCourse mainCourse5 = new MainCourse("Ribs", "Rp.100.000", 4.0, "Main Course", "No");
        MainCourse mainCourse6 = new MainCourse("Pizza", "Rp.65.000", 3.4, "Main Course", "No");
        MainCourse mainCourse7 = new MainCourse("Burger", "Rp.50.000", 5.0, "Main Course", "Yes");

        // Menginisialisasi objek Dessert
        Dessert dessert1 = new Dessert("Chocolate Cake", "Rp.28.000", 4.8, "Dessert", "Yes");
        Dessert dessert2 = new Dessert("Tiramisu", "Rp.25.000", 3.9, "Dessert", "No");
        Dessert dessert3 = new Dessert("Cheesecake", "Rp.30.000", 4.3, "Dessert", "Yes");
        Dessert dessert4 = new Dessert("Ice Cream Sundae", "Rp.18.000", 4.7, "Dessert", "Yes");

        // Menginisialisasi objek Drinks
        Drinks drink1 = new Drinks("Orange Juice", "Rp.10.000", 4.5, "Cold", "Yes");
        Drinks drink2 = new Drinks("Apple Juice", "Rp.10.000", 3.9, "Cold", "No");
        Drinks drink3 = new Drinks("Avocado Juice", "Rp.10.000", 3.8, "Cold", "No");
        Drinks drink4 = new Drinks("Iced Tea", "Rp.5.000", 4.5, "Cold", "Yes");
        Drinks drink5 = new Drinks("Coffee", "Rp.7.000", 4.0, "Hot", "No");

        // Menginisialisasi MenuStock
        MenuStock menuStock = new MenuStock(); 

        // Menginisialisasi Koki dengan MenuStock
        Koki koki1 = new Koki("Ilham", "Head Chef", "Appetizer", 5, true, menuStock);
        Koki koki2 = new Koki("Juna Agus", "Head Chef", "Main Course", 13, true, menuStock);
        Koki koki3 = new Koki("Renatta", "Pastry Chef", "Dessert", 10, true, menuStock);
        Koki koki4 = new Koki("Akbar", "Sous Chef", "Drink", 8, true, menuStock);

        // Menginisialisasi ShiftKoki
        ShiftKoki Skoki1 = new ShiftKoki("Ilham", "Head Chef", "Appetizer", 5, true, menuStock, "08:00 - 10:00");
        ShiftKoki Skoki2 = new ShiftKoki("Juna Agus", "Head Chef", "Main Course", 13, true, menuStock, "10:00 - 13:00");
        ShiftKoki Skoki3 = new ShiftKoki("Renatta", "Pastry Chef", "Dessert", 10, true, menuStock, "13:00 - 16:00");
        ShiftKoki Skoki4 = new ShiftKoki("Akbar", "Sous Chef", "Drink", 8, true, menuStock, "16:00 - 18:00");

        // Menginisialisasi Restaurant
        Restaurant restaurant = new Restaurant("Five Spices", "PIK", 1945, "Robben Van Deuc Wewengkang & Setiadi Deur Vand Teach", 4.89);

        // Terdapat list nama orang yang mengantri
        FiveSpicesQueue queue = new FiveSpicesQueue();
        queue.enqueue(new Customer("Kobe", 1, false));
        queue.enqueue(new Customer("Jampar", 2, false));
        queue.enqueue(new Customer("Lisa", 3, false));
        

        System.out.println();
        // Memulai loop utama yang berjalan terus-menerus sampai ada kondisi untuk keluar
        while (true) {
            // Memanggil metode yang mungkin menampilkan pesan sambutan dari restoran
            restaurant.welcoming();
            System.out.println("....................");
            System.out.println("1. Display Restaurant Info");
            System.out.println("2. Display Food Menu");
            System.out.println("3. Order Food ");
            System.out.println("4. Display Order");
            System.out.println("5. Display Table Info");
            System.out.println("6. Print Receipt");
            System.out.println("7. View Chef Shift Work");
            System.out.println("8. View Activity Log");
            System.out.println("9. Keluar");
            System.out.print("Pilih menu (1-9): ");
            try {
                int choice = scan.nextInt();

            // Memulai switch case untuk mengeksekusi tindakan berdasarkan pilihan pengguna
            switch (choice) {
                case 1:
                    // Flag untuk mengontrol loop menu informasi restoran
                    boolean infoMenuQuit = false;
                    // Loop untuk menu informasi restoran yang berulang sampai pengguna memilih untuk keluar
                    while (!infoMenuQuit) {
                        restaurant.displayInfoRestaurant();
                        Koki.displayAllKokiInfo();
                        System.out.println("1. Tulis Feedback");
                        System.out.println("2. Display Feedback");
                        System.out.println("3. Undo Feedback");
                        System.out.println("4. Kembali ke Menu Utama");
                        System.out.print("Pilih aksi (1-4): ");
                        int infoChoice = scan.nextInt();
                        scan.nextLine(); 

                        // Meminta pelanggan memasukkan feedback ke restoran
                        switch (infoChoice) {
                            case 1:
                                System.out.print("Masukkan feedback Anda: ");
                                String feedback = scan.nextLine();
                                restaurant.addFeedback(feedback);
                                break;
                            case 2:
                                boolean feedbackMenuQuit = false;
                                while (!feedbackMenuQuit) {
                                    restaurant.displayFeedbacks();
                                    System.out.println("1. Quit");
                                    System.out.print("Pilih aksi (1): ");
                                    int feedbackChoice = scan.nextInt();
                                    if (feedbackChoice == 1) {
                                        feedbackMenuQuit = true;
                                    } else {
                                        System.out.println("Pilihan tidak valid. Silakan coba lagi.");
                                    }
                                }
                                break;
                            case 3:
                                restaurant.undoFeedback();
                                System.out.println("Feedback telah berhasil di undo.");
                                break;
                            case 4:
                                infoMenuQuit = true;
                            default:
                                System.out.println("Pilihan tidak valid. Silakan coba lagi.");
                        }
                    }
                    break;

                case 2:
                    // Menambahkan menu ke daftar menu
                    // Appetizer
                    menuListAp.addMenu(appettizer1);
                    menuListAp.addMenu(appettizer2);
                    menuListAp.addMenu(appettizer3);
                    menuListAp.addMenu(appettizer4);
                    menuListAp.addMenu(appettizer5);

                    // MainCourse
                    menuListM.addMenu(mainCourse1);
                    menuListM.addMenu(mainCourse2);
                    menuListM.addMenu(mainCourse3);
                    menuListM.addMenu(mainCourse4);
                    menuListM.addMenu(mainCourse5);
                    menuListM.addMenu(mainCourse6);
                    menuListM.addMenu(mainCourse7);

                    // Dessert
                    menuListDs.addMenu(dessert1);
                    menuListDs.addMenu(dessert2);
                    menuListDs.addMenu(dessert3);
                    menuListDs.addMenu(dessert4);

                    // Drinks
                    menuListDr.addMenu(drink1);
                    menuListDr.addMenu(drink2);
                    menuListDr.addMenu(drink3);
                    menuListDr.addMenu(drink4);
                    menuListDr.addMenu(drink5);

                    // Meminta pelanggan untuk memilih tipe menu
                    System.out.println("Silahkan Pilih Tipe Menu :");
                    System.out.println("1. Appetizer\n2. Main Course\n3. Dessert\n4. Drinks");
                    System.out.println("Masukkan Nomor (1-4):");
                    int pilihmenu = scan.nextInt();

                    switch (pilihmenu) {
                        case 1:
                            String userInputAp = null;
                            do {
                                // Menampilkan menu saat ini
                                menuListAp.displayCurrentMenu();
                                System.out.println("Press 'n' for next menu, 'p' for previous menu, or 'q'");

                            userInputAp = scan.next();
                    
                            // Navigasi menu
                            if (userInputAp.equals("n")) {
                                menuListAp.next();
                            } else if (userInputAp.equals("p")) {
                                menuListAp.prev();
                            }
                        } while (!userInputAp.equals("q"));
    
                        System.out.println("");
                        
                            break;

                        case 2: 
                        String userInputM = null;
                        do {
                            // Menampilkan menu saat ini
                            menuListM.displayCurrentMenu();
                            System.out.println("Press 'n' for next menu, 'p' for previous menu, or 'q' to quit: ");
                            userInputM = scan.next();
                    
                            // Navigasi menu
                            if (userInputM.equals("n")) {
                                menuListM.next();
                            } else if (userInputM.equals("p")) {
                                menuListM.prev();
                            }
                        } while (!userInputM.equals("q"));
    
                        System.out.println("");

                            break;

                        case 3: 
                        String userInputDs = null;
                        do {
                            // Menampilkan menu saat ini n untuk menu selanjutnya, p untuk menu sebelumnya dan q untuk quit
                            menuListDs.displayCurrentMenu();
                            System.out.println("Press 'n' for next menu, 'p' for previous menu, or 'q' to quit: ");
                            userInputDs = scan.next();
                    
                            // Navigasi menu
                            if (userInputDs.equals("n")) {
                                menuListDs.next();
                            } else if (userInputDs.equals("p")) {
                                menuListDs.prev();
                            }
                        } while (!userInputDs.equals("q"));
    
                        System.out.println("");

                            break;

                        case 4: String userInputDr = null;
                        do {
                            // Menampilkan menu saat ini n untuk menu selanjutnya, p untuk menu sebelumnya dan q untuk quit
                            menuListDr.displayCurrentMenu();
                            System.out.print("Press 'n' for next menu, 'p' for previous menu, or 'q' to quit: ");
                            userInputDr = scan.next();
                    
                            // Navigasi menu
                            if (userInputDr.equals("n")) {
                                menuListDr.next();
                            } else if (userInputDr.equals("p")) {
                                menuListDr.prev();
                            }
                        } while (!userInputDr.equals("q"));
    
                        System.out.println("");

                            break;

                        default:
                        System.out.println("Masukan Nomor Valid");
                        break;
                    }
                    break;


                // Meminta pengguna memasukkan tipe makanan yang ingin dipesan
                case 3:
                System.out.println("Masukkan tipe Makanan yang ingin Dipesan :");
                System.out.println("1. Appettizer\n2. Main Course\n3. Dessert\n4. Drinks");
                System.out.printf("Masukkan Nomor (1-4):");
                int tipeMakanan = scan.nextInt();
                scan.nextLine();
            
                switch (tipeMakanan) {
                    case 1:
                        System.out.println("-------------------------------------------");
                        System.out.print("Masukkan Nama Makanan : ");
                        String namaMakananAp = scan.nextLine();
            
                        if (menuStock.checkStock(namaMakananAp)) {
                            koki1.prepare(namaMakananAp);
            
                            System.out.print("Masukkan Harga Makanan : ");
                            double hargaMakananAP = scan.nextDouble();
            
                            System.out.print("Masukkan Jumlah yang ingin dipesan: ");
                            int jumlahMakananAP = scan.nextInt();
            
                            pesananList.add(new Pesanan(namaMakananAp, hargaMakananAP, jumlahMakananAP));
            
                            koki1.serve(namaMakananAp);
                        } else {
                            System.out.println("Stock Habis Maaf.");  
                        }
                        break;
            
                    case 2:
                        System.out.println("-------------------------------------------");
                        System.out.print("Masukkan Nama Makanan : ");
                        String namaMakananMC = scan.nextLine();
            
                        if (menuStock.checkStock(namaMakananMC)) {
                            koki2.prepare(namaMakananMC);
            
                            System.out.print("Masukkan Harga Makanan : ");
                            double hargaMakananMC = scan.nextDouble();
            
                            System.out.print("Masukkan Jumlah yang ingin dipesan: ");
                            int jumlahMakananMC = scan.nextInt();
            
                            koki2.serve(namaMakananMC);
                            // Menambahkan pesanan ke ArrayList pesanan
                            pesananList.add(new Pesanan(namaMakananMC, hargaMakananMC, jumlahMakananMC));
                        } else {
                            System.out.println("Stock Habis Maaf.");
                        }
                        break;
            
                    case 3:
                        System.out.println("-------------------------------------------");
                        System.out.print("Masukkan Nama Makanan : ");
                        String namaMakananDs = scan.nextLine();
            
                        if (menuStock.checkStock(namaMakananDs)) {
                            koki3.prepare(namaMakananDs);
            
                            System.out.print("Masukkan Harga Makanan : ");
                            double hargaMakananDs = scan.nextDouble();
            
                            System.out.print("Masukkan Jumlah yang ingin dipesan: ");
                            int jumlahMakananDs = scan.nextInt();
            
                            koki3.serve(namaMakananDs);
                            // Menambahkan pesanan ke ArrayList pesanan
                            pesananList.add(new Pesanan(namaMakananDs, hargaMakananDs, jumlahMakananDs));
                        } else {
                            System.out.println("Stock Habis Maaf.");     
                        }
                        break;
            
                    case 4:
                        System.out.println("-------------------------------------------");
                        System.out.print("Masukkan Nama Minuman : ");
                        String namaMakananDr = scan.nextLine();
            
                        if (menuStock.checkStock(namaMakananDr)) {
                            koki4.prepare(namaMakananDr);
            
                            System.out.print("Masukkan Harga Minuman : ");
                            double hargaMakananDr = scan.nextDouble();
            
                            System.out.print("Masukkan Jumlah yang ingin dipesan: ");
                            int jumlahMakananDr = scan.nextInt();
            
                            koki4.serve(namaMakananDr);
                            // Menambahkan pesanan ke ArrayList pesanan
                            pesananList.add(new Pesanan(namaMakananDr, hargaMakananDr, jumlahMakananDr));
                        } else {
                            System.out.println("Stock Habis Maaf.");  
                        }
                        break;
            
                    default:
                        System.out.println("-------------------------------------------");
                        System.out.println("Tidak Valid");
                        break;
                }
                System.out.println("-------------------------------------------");
                break;
            
                
                // Meminta pelanggan untuk memilih nomor meja untuk makan
                case 4: 
                if (pesananList.isEmpty()) {
                    System.out.println("\n--------------------------------");
                    System.out.println("Invalid input, order first");
                    System.out.println("--------------------------------");
                } else {
                    while (true) {
                        System.out.println("===================================================");
                        System.out.println("                    Display Order");
                        System.out.println("===================================================");
                        // Hanya menampilkan daftar pesanan tanpa mencetak struk
                        for (Pesanan pesanan : pesananList) {
                            System.out.println("---------------------------------------------------");
                            System.out.println("Nama Menu: " + pesanan.getNama() + ", Harga: " + pesanan.getHarga() + ", Jumlah: " + pesanan.getJumlah());
                        }
                        System.out.println("---------------------------------------------------");
                        System.out.println("1. Add More Order");
                        System.out.println("2. Remove Order");
                        System.out.println("3. Quit");
                        System.out.println("---------------------------------------------------");
                        System.out.print("Pilihan: ");
                        int submenuChoice = scan.nextInt();
                        scan.nextLine(); // consume newline
                        switch (submenuChoice) {
                            case 1:
                                menuStock.handleOrderFood(scan, pesananList);
                                break;
                            case 2:
                                System.out.print("Masukkan Nama Makanan yang ingin dihapus: ");
                                String namaMakanan = scan.nextLine();
                                boolean found = false;
                                for (Pesanan pesanan : pesananList) {
                                    if (pesanan.getNama().equalsIgnoreCase(namaMakanan)) {
                                        pesananList.remove(pesanan);
                                        found = true;
                                        System.out.println("Pesanan telah dihapus.");
                                        break;
                                    }
                                }
                                if (!found) {
                                    System.out.println("Pesanan tidak ditemukan.");
                                }
                                break;
                            case 3:

                               // Keluar dari method, sehingga kembali ke menu utama
                            default:
                                System.out.println("Anda baru saja keluar dari Display Order.");
                        }
                        if (submenuChoice == 3) {
                            break; // Keluar dari loop while setelah menyelesaikan operasi di dalam case 3
                        }
                    }
                }break;
               
               
                // Mencetak struk berisi list pesanan
                case 5:
                table.displayTableInfo();
                System.out.print("Pilih nomor meja untuk makan: ");
                    if (scan.hasNextInt()) {
                    int nomorMejaa = scan.nextInt();
                        if (nomorMejaa >= 1 && nomorMejaa <= 10) {
                            // Reserving table
                            String nomorMejaStr = "Meja " + nomorMejaa;
                            table.reserveTable(nomorMejaStr);
                    } else {
                    System.out.println("Nomor meja tidak valid.");
                    }
                } else {
                System.out.println("Input harus berupa angka.");
                scan.next(); 
                }

                // Membatalkan meja yang sudah dipesan
                System.out.println("Apakah anda ingin merubah meja anda?");
                String unreservedMeja = scan.next();
                scan.nextLine();

                // Mengecek apakah pengguna ingin membatalkan reservasi meja
                    if (unreservedMeja.equals("y")) {
                        // Meminta pengguna untuk memasukkan nomor meja yang ingin dibatalkan reservasinya
                        System.out.println("Masukan Nomor Meja yang ingin di cancel :");
                        // Membaca dan menyimpan input nomor meja dari pengguna
                        int nomorMejaUnreserved = scan.nextInt();
                        // Memastikan bahwa nomor meja berada dalam rentang yang valid (1 hingga 10)
                        if (nomorMejaUnreserved >= 1 && nomorMejaUnreserved <= 10) {
                            // Mengonversi nomor meja ke format string yang sesuai dengan format yang digunakan dalam metode unreserveTable
                            String nomorMejaStr = "Meja " + nomorMejaUnreserved;
                            // Memanggil metode unreserveTable untuk membatalkan reservasi meja dengan nomor yang diberikan
                            table.unreserveTable(nomorMejaStr);
                        } 
                    } 
                
                // Meminta pelanggan untuk mengambil nomor antrian
                System.out.println("Ambil Nomor Antrian? :");
                System.out.println("1. Ya\n2. Tidak");
                int inputNoAntri = scan.nextInt();
                scan.nextLine();

                // Meminta pelanggan membuat nomor antri
                switch (inputNoAntri) {
                    case 1:
                    int noAntriskrg = 3;
                    System.out.print("Masukan Nama Anda : ");
                    String nama = scan.next();
                    scan.nextLine();

                    System.out.println("Apakah Kamu Member VIP? (y/n) :");
                    String inputVip = scan.next();
                    scan.nextLine();

                    if (inputVip.equals("y")) {
                        queue.enqueue(new Customer(nama, noAntriskrg+1, true));
                        noAntriskrg =+ noAntriskrg;
                            break;
                    } else if (inputVip.equals("n")) {
                        queue.enqueue(new Customer(nama, noAntriskrg+1, false));
                        noAntriskrg =+ noAntriskrg;
                            break;
                    }

                    break;

                    case 2:
                    System.out.println("Terimakasih, Pastikan Anda Sudah Memiliki Nomor Antri");
                    break;

                    default:
                    System.out.println("Input Tidak Valid");
                    break;
                }
                boolean sementara = true;

                // Terdapat menu pada antrian
                while (sementara) {
                    System.out.println("Pilih Aksi Anda :");
                    System.out.println("1. Tampilkan Antrian\n2. Dequeue Antrian\n3. Tidak (Quit)");
                    int displayQueue = scan.nextInt();
                    scan.nextLine();
    
                    if (displayQueue == 1) {
                    System.out.println(" _______________________________");
                    System.out.println("| Nama       | NoAntri | VIP?  |");
                    System.out.println(" ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾");
                    queue.displayQueue();
                    } else if (displayQueue == 2) {
                    queue.dequeue();
                    } else if (displayQueue == 3) {
                        break;
                    } else {
                        System.out.println("Input Tidak Valid.");
                        sementara = false;
                        break;
                    } 
                 }


                break;  
                
                // Mencetak list shift koki
                case 6 :
                Pesanan.cetakStruk(pesananList);
                 break;

                // Terdapat menu yang hanya bisa dilihat oleh pemiliki restoran
                case 7:
                shiftListKoki.addShift(Skoki1);
                shiftListKoki.addShift(Skoki2);
                shiftListKoki.addShift(Skoki3);
                shiftListKoki.addShift(Skoki4);

                String shiftInput;
                do {
                    // Menampilkan menu saat ini
                    shiftListKoki.displayCurrentShift();
                    System.out.println("Press 'n' for next Shift, or 'q' to quit: ");
                    shiftInput = scan.next();
                
                    // Navigasi menu
                    if (shiftInput.equals("n")) {
                        shiftListKoki.next();
                    } 
                } while (!shiftInput.equals("q"));
            
                    break;

                // Terdapat output untuk tabel akhir
                case 8 :
                System.out.println("HALAMAN INI HANYA UNTUK OWNER DAN BERSIFAT PRIVAT !");
                System.out.println("Masukan Password :");
                String passWord = scan.next();
                scan.nextLine();

                // Verifikasi password
                if (passWord.equals("5Spices")) {
                    System.out.println("Verifikasi Sukses...\n\nSelamat Datang Robben !");

                    System.out.println("Activity Log:");

                boolean activityLogQuit = false;
                activityLog.printCurrentLog(); // Memastikan log aktivitas pertama kali

                while (!activityLogQuit) {
                    System.out.println("\nActivity Log:");
                    System.out.println("1. Next"); // Opsi untuk melihat log berikutnya
                    System.out.println("2. Previous"); // Opsi untuk melihat log sebelumnya
                    System.out.println("3. Quit"); // Opsi untuk keluar dari log aktivitas
                    System.out.print("Pilih aksi (1-3): ");
                    int activityChoice = scan.nextInt();
                    switch (activityChoice) {
                        case 1:
                        // Menampilkan log berikutnya
                            activityLog.nextLog(); 
                            break;
                        case 2:
                        // Menampilkan log sebelumnya
                            activityLog.prevLog();
                            break;
                        case 3:
                        // Mengakhiri loop dan keluar dari log aktivitas
                            activityLogQuit = true;
                            System.out.println("Keluar dari Aktivitas Restoran.");
                            break;
                        default:
                            System.out.println("Pilihan tidak valid. Silakan coba lagi.");
                    }
                }
                break;
                } else {
                    // Akan keluar output berikut jika verifikasi password salah
                    System.out.println("Verifikasi Gagal.");
                }
                
                    break;
                
                // Akan keluar output penutup
                case 9:
                System.out.println("\n===================================================");
                System.out.println("    Terima Kasih telah datang ke restoran kami!");
                System.out.println("===================================================\n");
                System.exit(0); // Mengakhiri program
                    break;


                default:
                // Pesan kesalahan untuk nomor menu yang tidak valid
                System.out.println("Nomor Invalid!"); 
                    break;
            } 
            
            } catch (InputMismatchException e) {
                // Pesan kesalahan untuk input yang tidak valid
                System.out.println("Input tidak valid. Silakan masukkan data tipe angka.");
                scan.next(); 
            }
        
        }

     } 
}