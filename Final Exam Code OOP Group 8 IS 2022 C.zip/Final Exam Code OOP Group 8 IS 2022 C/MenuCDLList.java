// Mendeklarasikan kelas MenuCDLList
public class MenuCDLList {
    private MenuItem head;
    private MenuItem current;

    // Terdapat method untuk menambahkan menu ke dalam linked list
    public void addMenu(Menu menuItem) {
        MenuItem newNode = new MenuItem(menuItem);
        if (head == null) {
            head = newNode;
            head.next = head;
            head.prev = head;
            current = head;
        } else {
            MenuItem last = head.prev;
            last.next = newNode;
            newNode.prev = last;
            newNode.next = head;
            head.prev = newNode;
        }
    }

    // Terdapat method untuk menampilkan menu saat ini
    public void displayCurrentMenu() {
        if (current != null) {
            System.out.println("=======================================");
            System.out.println("            Current Menu");
            System.out.println("=======================================");
            current.menu.displayMenuu();
            System.out.println("---------------------------------------");
        } else {
            System.out.println("Menu not available.");
        }
    }

    // Terdapat method untuk bergerak ke menu berikutnya
    public void next() {
        if (current != null) {
            current = current.next;
        }
    }

    // Terdapat method untuk bergerak ke menu sebelumnya
    public void prev() {
        if (current != null) {
            current = current.prev;
        }
    }

    // Terdiri atas kelas privat static node-menu untuk linked list
    private static class MenuItem {
        Menu menu;
        MenuItem next;
        MenuItem prev;

        MenuItem(Menu menu) {
            this.menu = menu;
            this.next = null;
            this.prev = null;
        }
    }
}