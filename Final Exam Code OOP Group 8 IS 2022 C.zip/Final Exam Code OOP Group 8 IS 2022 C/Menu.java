// Mendeklarasikan kelas Abstract Menu 
public abstract class Menu  {
    // Terdiri atas atribut privat String nama, String harga, double rating, String type, String isFavorite
    private String nama;
    private String harga;
    private double rating;
    private String type;
    private String isFavorite;

/*String nama digunakan untuk nama menu, String digunakan untuk harga menu, 
double rating digunakan untuk rating sebuah menu dari 1-5, String type digunakan untuk mengetahui jenis menu, 
String isFavorite digunakan untuk mengetahui apakah menu itu favorit atau bukan*/

// Terdapat konstruktor dengan variabel String nama, String harga, double rating, String type, String isFavorite
    public Menu (String nama , String harga, double rating, String type, String isFavorite){
        this.nama = nama ;
        this.harga = harga;
        this.rating = rating;
        this.type = type;
        this.isFavorite = isFavorite;
    }

    // Menggunakan method Getter
    public String getName () {
        return nama;
    }

    public String getHarga(){
        return harga;
    } 

    public double getRating (){
        return rating;
    }

    public String getType(){
        return type;
    }

    public String getIsfavorite (){
        return isFavorite;
    }

    // Menggunakan method Setter
    public void setIsfavorite (String isFavorite) {
        this.isFavorite = isFavorite;
    }

    // Terdapat method displayMenuu() yang akan digunakan kepada subclass Menu nanti
    public void displayMenuu() {

    }
    
    // Terdapat method displayMenuWithBorders() yang akan digunakan di Main.
    /*displayMenuWithBorders() merupakan method untuk menampilkan menu dengan 
    border agar saat user menampilkan menu, menu yang ditampilkan itu lebih rapi*/
    
}