import java.util.ArrayList;
import java.util.Scanner;

// Menginisialisasi kelas Pesanan dengan atribut privat String nama, double harga, int jumlah
class Pesanan {
    private String nama;
    private double harga;
    private int jumlah;

    // Terdapat konstruktor kelas Pesanan dengan parameter nama, harga dan jumlah
    public Pesanan(String nama, double harga, int jumlah) {
        this.nama = nama;
        this.harga = harga;
        this.jumlah = jumlah;
    }

    // Terdapat method Getter untuk nama pesanan
    public String getNama() {
        return nama;
    }

    // Terdapat method Getter untuk harga pesanan
    public double getHarga() {
        return harga;
    }

    // Terdapat method Getter untuk jumlah pesanan
    public int getJumlah() {
        return jumlah;
    }

    // Terdapat objek Transaction dengan method untuk menangani proses pembayaran
    public static void handlePayment(double amount, ArrayList<Pesanan> pesananList) {
        Scanner scanner = new Scanner(System.in);
        boolean paymentSuccess = false;

        // Loop hingga pembayaran berhasil diproses
        while (!paymentSuccess) {
            System.out.println("==================================================");
            System.out.println("               Choose Payment Method              ");
            System.out.println("==================================================");
            System.out.println("1. Cash");
            System.out.println("2. Debit");
            System.out.println("--------------------------------------------------");
            System.out.print("Enter your choice: ");
            int method = scanner.nextInt();

            // Menangani pembayaran Cash
            if (method == 1) {
                System.out.println("==================================================");
                System.out.println(amount + " has been paid using cash.");
                System.out.println("==================================================");
                paymentSuccess = true;
            // Menangani pembayaran kartu debit
            } else if (method == 2) {
                System.out.println("==================================================");
                System.out.print("Enter your debit card number (12 digits): ");
                String cardNumber = scanner.next();
                if (cardNumber.length() == 12 && cardNumber.matches("\\d+")) {
                    System.out.println(amount + " has been paid using debit card.");
                    System.out.println("==================================================");
                    paymentSuccess = true;
                // Jika nomor kartu tidak sesuai
                } else {
                    System.out.println("\n--------------------------------------------------");
                    System.out.println("Payment failed. Invalid card number.");
                    System.out.println("--------------------------------------------------\n");
                }
                // Jika method pembayaran tidak sesuai
            } else {
                System.out.println("--------------------------------------------------");
                System.out.println("Invalid payment method selected.");
                System.out.println("--------------------------------------------------");
            }
        }

        // Menghapus daftar pesanan setelah pembayaran berhasil
        if (paymentSuccess) {
            pesananList.clear();
        }
    }

    // Terdapat method untuk memprint struk pesanan
    public static void cetakStruk(ArrayList<Pesanan> pesananList) {
        double totalHarga = 0;
        System.out.println("==================================================");
        System.out.println("                   Struk Pesanan                  ");
        System.out.println("==================================================");
        System.out.printf("%-20s %-10s %-10s%n", "Nama Menu", "Harga", "Jumlah");
        System.out.println("--------------------------------------------------");

        // Terdapat loop pada setiap item pesanan dan memprint detail
        for (Pesanan pesanan : pesananList) {
            System.out.printf("%-20s %-10.2f %-10d%n", pesanan.getNama(), pesanan.getHarga(), pesanan.getJumlah());
            totalHarga += pesanan.getHarga() * pesanan.getJumlah();
        }

        System.out.println("--------------------------------------------------");
        System.out.printf("Total Harga: %.2f%n", totalHarga);
        System.out.println("==================================================");

        // Memanggil method handlePayment untuk memproses pembayaran
        handlePayment(totalHarga, pesananList);
    }

    // Terdapat method untuk menjumlahkan total harga dari semua pesanan item
    public static double hitungTotal(ArrayList<Pesanan> pesananList) {
        double total = 0;
        for (Pesanan pesanan : pesananList) {
            total += pesanan.getHarga() * pesanan.getJumlah();
        }
        return total;
    }}