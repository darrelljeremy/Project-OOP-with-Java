/*Mendeklarasikan kelas koki untuk menyiapkan dan melayani makanan yang mempunyai variabel
 String name, String position, String speciality, boolean isCertified, int experience, MenuStock menuStock;

Terdiri atas class Koki mengimplementasi 2 interface yaitu IPrepare, dan Iservefood*/
public class Koki implements IPrepare, Iservefood {
    // Referensi ke node pertama dalam linked list koki
    private static Koki head;
    
    // Terdiri atas variabel yang menyimpan informasi dibawah :
    // Menyimpan nama koki
    private String name;
    // Menyimpan posisi koki ( Chef, Sous Chef, dll )
    private String position;
    // Menyimpan spesialisasi koki ( Italian cuisine, Pastry, dll )
    private String speciality;
    // Menyimpan status apakah koki bersertifikat atau tidak
    private boolean isCertified;
    // Menyimpan jumlah tahun pengalaman koki
    private int experience;
    // Menyimpan referensi ke objek MenuStock yang berhubungan dengan koki
    private MenuStock menuStock;
    // Menyimpan referensi ke objek Koki berikutnya dalam linked list
    private Koki next;

    // Terdiri atas konstruktor untuk class Koki dengan parameter nama, posisi, keahlian, pengalaman, sertifikasi dan stok menu
    public Koki(String name, String position, String speciality, int experience, boolean isCertified, MenuStock menuStock) {
        this.name = name;
        this.position = position;
        this.speciality = speciality;
        this.experience = experience;
        this.isCertified = isCertified;
        this.menuStock = menuStock;
        this.next = null; // Initialize next to null
        addToLinkedList(this);
    }

    @Override
        /*Implementasi method prepare dari IPrepare. 
        Method untuk menyiapkan pesanan dengan memeriksa jika makanan diminta tersedia dalam stok*/

    public void prepare(String menuName) {
        if (menuStock.checkStock(menuName)) {
            System.out.println(name + " have started to prepared the dish " + menuName);
            System.out.println("");
        } else {
            System.out.println("Sorry, " + menuName + " is not available or out of stock.");
        }
    }

    /*Implementasi method prepare dari Iervefood. 
        Method untuk menyiapkan pesanan dengan memeriksa jika makanan diminta tersedia dalam stok*/
    // Metode untuk mengurangi stok menu makanan saat melayani pesanan
    @Override
    public void serve(String menuName) {
        if (menuStock.checkStock(menuName)) {
            System.out.println(name + " are done with " + menuName + " please wait until your Queue is up.");
            System.out.println("");
            // Kurangi stok setelah melayani pesanan

        } else {
            System.out.println("Sorry, " + menuName + " is not available or out of stock.");
        }
    }

    // Terdapat method untuk menampilkan informasi dari koki
    public void displayKokiInfo (){
        System.out.println("Name : " + getName());
        System.out.println("Posistion : " + getPosition());
        System.out.println("Speciality : " + getSpeciality());
        System.out.println("Experience : " + getExperience());
        System.out.println("Certified Chef : " + isCertified());
        System.out.println("");
        
    }

    private void addToLinkedList(Koki koki) {
        // Jika head masih null, maka koki baru ini menjadi head dari linked list
        if (head == null) {
            head = koki;
            // Jika head sudah ada, maka kita mulai dari head
        } else {
            Koki current = head;
            // Iterasi hingga menemukan node terakhir (next == null)
            while (current.next != null) {
                current = current.next;
            }
            // Menambahkan koki baru di akhir linked list
            current.next = koki;
        }
    }

    // SINGLE LINKED LIST MEMAKAI NEXT.
    public static void displayAllKokiInfo() {
        System.out.println("--------------------------");
        System.out.println("         Our Chefs        ");
        System.out.println("--------------------------");
        Koki current = head;
        while (current != null) {
            current.displayKokiInfo();
            current = current.next;
        }
    }

    /*Metode getter dan setter koki yaitu untuk mengambil data nama getName(), 
    posisi getPosition(), specialitas koki apa getSpeciality(),berapa tahun berpengalaman getExperience(),
    dan apakah si koki bersertifikasi isCertified().
    */

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public String getSpeciality() {
        return speciality;
    }

    public int getExperience() {
        return experience;
    }

    public boolean isCertified() {
        return isCertified;
    }

    public void setCertified(boolean certified) {
        isCertified = certified;
    }
    
    
}