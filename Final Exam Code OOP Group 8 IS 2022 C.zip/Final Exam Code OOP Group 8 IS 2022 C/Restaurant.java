// Mendeklarasikan kelas Restaurant
public class Restaurant {
    // Mendeklarasikan atribut-atribut yang dimiliki oleh kelas Restaurant
    private String location; // Lokasi dari restoran
    private String name; // Nama dari restoran
    private int year; // Tahun berdirinya restoran
    private String owner; // Nama pemilik restoran
    private double rating; // Rating restoran
    private String nomorMeja; // Nomor meja di restoran
    private String status; // Status ketersediaan restoran
    private Feedback feedbackStack; // Stack untuk menyimpan feedback

    // Terdapat konstruktor untuk membuat objek Restaurant dengan parameter yang diberikan
    public Restaurant(String name, String location, int year, String owner, double rating) {
        // Menginisialisasi atribut-atribut dari objek Restaurant sesuai dengan parameter yang diberikan
        this.name = name;
        this.location = location;
        this.year = year;
        this.owner = owner;
        this.rating = rating;
        this.status = "Available"; // Set status awal restoran sebagai "Available"
        this.feedbackStack = new Feedback(); // Inisialisasi feedbackStack
    }
    
    // Terdapat method untuk menyambut pengunjung ke restoran
    public void welcoming() {
        System.out.println("");
        System.out.println("Welcome to " + name + " in " + location);
    }

    // Terdapat method untuk menampilkan informasi lengkap tentang restoran
    public void displayInfoRestaurant() {
        System.out.println("Restaurant Name      : " + name);
        System.out.println("Restaurant Location  : " + location);
        System.out.println("Founded Since        : " + year);
        System.out.println("Founder & Co Founder : " + owner );
        System.out.println("Rating               : " + rating);
        System.out.println("");
    }

    // Getter untuk mendapatkan nomor meja dari restoran
    public String getNomorMeja() {
        return nomorMeja;
    }

    // Getter untuk mendapatkan status ketersediaan restoran
    public String getStatus() {
        return status;
    }

    // Setter untuk mengatur nomor meja di restoran
    public void setNomorMeja(String nomorMeja) {
        this.nomorMeja = nomorMeja;
    }

    // Setter untuk mengatur status ketersediaan restoran
    public void setStatus(String status) {
        this.status = status;
    }

    // Terdapat method untuk menambah feedback
    public void addFeedback(String feedback) {
        feedbackStack.push(feedback);
        System.out.println("Feedback berhasil ditambahkan.");
    }

    // Terdapat method untuk menampilkan feedback
    public void displayFeedbacks() {
        feedbackStack.displayFeedbacks();
    }

    // Mendeklarasikan kelas Feedback
    class Feedback {
        // Terdiri atas kelas privat static Node
        private static class Node {
            // Terdiri atas atribut untuk menyimpan feedback dan referensi ke node berikutnya
            String feedback;
            Node next;
    
            // Terdiri atas konstruktor Node yang menerima feedback
            Node(String feedback) {
                this.feedback = feedback;
            }
        }
    
        // Terdapat atribut privat untuk menunjuk ke node teratas dari stack
        private Node top;
    
        // Terdapat konstruktor Feedback menginisialisasi top sebagai null
        public Feedback() {
            top = null;
        }
    
        // Terdapat method untuk menambahkan feedback ke dalam stack
        public void push(String feedback) {
            Node newNode = new Node(feedback);
            newNode.next = top;
            top = newNode;
        }
    
        // Terdapat method untuk menghapus dan mengembalikan feedback teratas dari stack
        public String pop() {
            if (top == null) {
                return null;
            }
            String feedback = top.feedback;
            top = top.next;
            return feedback;
        }
    
        // Terdapat method untuk menampilkan semua feedback di stack
        public void displayFeedbacks() {
            Node current = top;
            // Jika tidak ada feedback, tampilkan pesan bahwa belum ada feedback
            if (current == null) {
                System.out.println("Belum ada feedback.");
                return;
            }
            // Jika ada feedback, tampilkan semua
            System.out.println("Feedback :");
            while (current != null) {
                System.out.println("------------------------------------");
                System.out.println("+++ " + current.feedback);
                System.out.println("------------------------------------\n");
                current = current.next;
            }
        }
        
    
        // Terdapat method untuk memeriksa stack kosong atau tidak
        public boolean isEmpty() {
            return top == null;
        }
    }

    // Terdapat method untuk membatalkan feedback
    public void undoFeedback() {
        // Mengambil umpan balik terakhir dari stack feedback
        String removedFeedback = feedbackStack.pop();
        // Jika feedback yang diambil tidak null berarti ada umpan balik yang berhasil di-undo
        if (removedFeedback != null) {
            // Akan terdapat output bahwa umpan balik tersebut berhasil di-undo
            System.out.println("Feedback berikut berhasil di-undo: " + removedFeedback);
        } else {
            // Jika tidak ada umpan balik yang bisa di-undo maka akan keluar output berikut
            System.out.println("Tidak ada feedback yang bisa di-undo.");
        }
    }

    
}