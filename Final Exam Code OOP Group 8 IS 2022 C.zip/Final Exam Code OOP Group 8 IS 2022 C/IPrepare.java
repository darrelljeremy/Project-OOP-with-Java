// Mendeklarasikan interface IPrepare
public interface IPrepare {
    // Terdapat method untuk menyiapkan makanan berdasarkan nama menu
    public void prepare(String menuName);
}
