import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;


// Mendeklarasikan kelas Table untuk merepresentasikan meja-meja di restoran
public class Table {
    // Mendeklarasikan atribut privat yang dimiliki oleh kelas Table
    private String nomorMeja; // Nomor meja
    private String status; // Status meja (Available/Occupied)
    private static ArrayList<Table> tables = new ArrayList<>(); // Variabel statik untuk menyimpan informasi meja
    private static Queue<String> antrian = new LinkedList<>(); // Variabel statik untuk menyimpan antrian
    private static int nomorAntrian = 1; // Variabel statik untuk mengatur nomor antrian

    // Terdapat konstruktor tanpa parameter untuk kelas Table
    public Table() {
    }

    // Terdapat konstruktor untuk membuat objek Table dengan nomor meja dan status yang diberikan
    public Table(String nomorMeja, String status) {
        this.nomorMeja = nomorMeja;
        this.status = status;
    }

    // Terdapat getter untuk mendapatkan nomor meja
    public String getNomorMeja() {
        return nomorMeja;
    }

    // Terdapat setter untuk mengatur nomor meja
    public void setNomorMeja(String nomorMeja) {
        this.nomorMeja = nomorMeja;
    }

    // Terdapat getter untuk mendapatkan status meja
    public String getStatus() {
        return status;
    }

    // Terdapat setter untuk mengatur status meja
    public void setStatus(String status) {
        this.status = status;
    }

    // Terdapat method untuk membuat contoh meja-meja di restoran (10 meja)
    public ArrayList<Table> createSampleRestaurants() {
        for (int i = 1; i <= 7; i++) {
            Table table = new Table("Meja " + i, "Available");
            // Menambahkan meja ke daftar meja
            tables.add(table); 
        }

        for (int i = 8; i <= 10; i++) {
            Table table = new Table("Meja " + i, "Occupied");
            // Menambahkan meja ke daftar meja
            tables.add(table); 
        }
        // Mengembalikan daftar meja yang telah dibuat
        return tables; 
    }

    // Terdapat method untuk menampilkan informasi tentang meja-meja di restoran
    public void displayTableInfo() {
        System.out.println("Table Information:");
        System.out.println("------------------");
        System.out.println("Nomor Meja\t   Status");
        for (Table table : tables) {
            System.out.println(table.getNomorMeja() + "\t\t" + table.getStatus());
        }
        System.out.println("------------------");
    }

    // Terdapat method untuk memesan meja dengan nomor meja yang diberikan
    public void reserveTable(String nomorMeja) {
        for (Table table : tables) {
            if (table.getNomorMeja().equals(nomorMeja)) {
                if (table.getStatus().equals("Available")) { // Jika meja tersedia
                    table.setStatus("Occupied"); // Set status meja menjadi "Occupied"
                    System.out.println("Meja " + nomorMeja + " telah berhasil dipesan.");
                } else { // Jika meja sudah terpesan
                    System.out.println("Meja " + nomorMeja + " sudah terpesan.");
                    break;
                }
                return;
            }
        }
        // Jika nomor meja tidak valid
        System.out.println("Nomor meja tidak valid.");
    }

    // Terdapat method untuk membatalkan meja dengan nomor meja yang diberikan 
    public void unreserveTable(String nomorMeja) {
        for (Table table : tables) {
            if (table.getNomorMeja().equals(nomorMeja)) {
                if (table.getStatus().equals("Occupied")) { // Jika meja tersedia
                    table.setStatus("Available"); // Set status meja menjadi "Occupied"
                    System.out.println("Meja " + nomorMeja + " telah berhasil dibatalkan.");
                } else { // Jika meja sudah terpesan
                    System.out.println("Meja " + nomorMeja + " belum terpesan.");
                    break;
                }
                return;
            }
        }
        // Jika nomor meja tidak valid
        System.out.println("Nomor meja tidak valid.");
    }

    // Terdapat method untuk mengambil nomor antrian
    public void ambilNomorAntrian() {
        String nomorAntri = "Nomor Antrian " + nomorAntrian++;
        antrian.add(nomorAntri);
        System.out.println("Nomor antrian Anda: " + nomorAntri);
    }

    // Terdapat method untuk mengecek apakah ada nomor antrian
    public boolean hasNomorAntri() {
        return !antrian.isEmpty();
    }

    // Terdapat method untuk menampilkan antrian
    public void displayQueue() {
        System.out.println("Antrian Saat Ini:");
        System.out.println("-----------------");
        for (String antri : antrian) {
            System.out.println(antri);
        }
        System.out.println("-----------------");
    }

}