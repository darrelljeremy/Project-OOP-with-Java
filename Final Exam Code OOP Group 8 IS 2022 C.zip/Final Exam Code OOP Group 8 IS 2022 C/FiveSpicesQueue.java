    /*Atribut dalam kelas FiveSpicesQueue terdiri dari front dan rear, yang keduanya merupakan referensi 
    ke node dalam struktur data antrian. front digunakan untuk menunjukkan node pertama (node) dalam 
    antrian, sementara rear menunjukkan node terakhir dalam antrian. */
    public class FiveSpicesQueue {
        private Node front;
        private Node rear;
    /*
    Konstruktor FiveSpicesQueue berperan dalam pembuatan objek antrian baru. Saat konstruktor ini dipanggil,
    objek antrian dibuat dengan menginisialisasi atribut front dan rear ke nilai null, menandakan bahwa
    pada awalnya, antrian tersebut kosong */
        public FiveSpicesQueue() {
            this.front = null;
            this.rear = null;
        }
    /*Metode enqueue(Customer customer) bertanggung jawab untuk menambahkan sebuah pelanggan ke dalam
    antrian. Saat metode ini dipanggil dengan sebuah objek Customer sebagai argumen, sebuah node baru 
    dibuat dengan pelanggan tersebut. Jika pelanggan tersebut merupakan VIP, node baru tersebut akan 
    ditambahkan di depan antrian, yaitu ke front. Namun, jika pelanggan tersebut merupakan pelanggan
    biasa, simpul baru akan ditambahkan di belakang antrian, yaitu ke rear. Dengan pendekatan ini,
    antrian mengikuti prinsip first-in-first-out (FIFO).  */
        public void enqueue(Customer customer) {
            Node nodeBaru = new Node(customer);
            if (customer.isVip) {
                // VIP customers ditujukan ke bagian depan
                nodeBaru.next = front;
                front = nodeBaru;
                if (rear == null) {
                    rear = nodeBaru;
                }
            } else {
                // Regular customers ditujukan ke bagian belakang
                if (rear != null) {
                    rear.next = nodeBaru;
                    rear = nodeBaru;
                } else {
                    front = rear = nodeBaru;
                }
            }
        }
    /*Metode dequeue() berperan dalam menghapus dan mengembalikan pelanggan dari depan antrian. Ketika 
    metode ini dipanggil, ia akan memeriksa apakah antrian kosong. Jika antrian kosong, metode akan
    mengembalikan nilai null, menandakan bahwa tidak ada pelanggan yang dapat dihapus. Namun, jika antrian 
    tidak kosong, pelanggan di depan antrian akan dihapus, dan referensi front akan dipindahkan ke pelanggan 
    berikutnya dalam antrian. Setelah penghapusan, metode akan memeriksa apakah setelah penghapusan antrian
    menjadi kosong. Jika ya, maka referensi rear juga akan diatur ke null, menandakan bahwa antrian telah 
    kosong sepenuhnya */
        public Customer dequeue() {
            if (front == null) {
                return null;
            }
            Customer customer = front.customer;
            front = front.next;
            if (front == null) {
                rear = null;
            }
            return customer;
        }
    /*Metode displayQueue() berfungsi untuk menampilkan seluruh isi dari antrian pelanggan. Proses dimulai 
    dari elemen front, yang merupakan pelanggan pertama dalam antrian. Setiap pelanggan dalam antrian 
    kemudian dicetak menggunakan metode toString() dari kelas Customer, sehingga informasi lengkap tentang 
    setiap pelanggan dapat ditampilkan. Proses pencetakan dilanjutkan hingga mencapai elemen rear, yang
    menandakan akhir dari antrian. */
        public void displayQueue() {
            Node temp = front;
            while (temp != null) {
                System.out.println(temp.customer);
                temp = temp.next;
            }
        }

    }

    /*Kelas inner Node berperan sebagai node dalam struktur data linked list yang digunakan untuk 
    merepresentasikan setiap pelanggan dalam antrian. Setiap node dalam linked list ini memiliki dua 
    atribut utama. Pertama adalah customer, yang merupakan atribut yang menampung objek Customer, 
    sehingga menyimpan informasi lengkap tentang pelanggan, termasuk nama, nomor antrian, dan status 
    keanggotaan VIP-nya. Atribut kedua adalah next, yang merupakan referensi ke simpul berikutnya dalam 
    antrian.  */
    class Node {
        Customer customer;
        Node next;

        Node(Customer customer) {
            this.customer = customer;
            this.next = null;
        }
    }