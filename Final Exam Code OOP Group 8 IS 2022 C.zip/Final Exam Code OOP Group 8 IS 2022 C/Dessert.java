// Mendeklarasikan kelas Dessert yang merupakan turunan dari kelas Menu
public class Dessert extends Menu {

    /* Terdiri atas konstruktor dengan parameter nama, harga, rating, jenis Dessert 
    dan apakah menu tersebut termasuk menu favorit atau tidak*/
    public Dessert(String nama, String harga, double rating, String type, String isFavorite) {
        super(nama, harga, rating, type, isFavorite);
    }
    
    // Dikarenakan adanya kelas abstract Menu, maka seluruh kelas turunan harus menggunakan method displayMenuu()

    // @Override adalah sebuah annotation yang digunakan untuk menandai bahwa sebuah metode dalam suatu kelas 
    //merupakan override dari metode yang sama dalam kelas induknya (superclass)

    @Override
    // Menampilkan menu dan menggunakan Getter agar mendapat nilai dari atribut tersebut
    public void displayMenuu(){
        System.out.println("Dessert's Name    : " + getName());
        System.out.println("Dessert's Price   : " + getHarga());
        System.out.println("Dessert's Rating  : " + getRating());
        System.out.println("Dessert's Type    : " + getType());
        System.out.println("Dessert's's Fav  : " + getIsfavorite());
    }
    // displayMenuu() di dalam kelas Dessert merupakan method untuk mengeprint semua menu Dessert.
    /* dan juga merupakan sebuah implementasi Polymorfism dimana nama methodnya sama, namun
      outputnya berbeda/*/

}