// Mendeklarasikan kelas Drink yang merupakan turunan dari kelas Menu
public class Drinks extends Menu {

    /*Terdiri atas konstruktor dengan parameter nama, harga, rating, jenis makanan 
    dan apakah menu tersebut termasuk menu favorit atau tidak */
    public Drinks(String nama, String harga, double rating, String type, String isFavorite) {
    // Memanggil konstruktor kelas induk dengan 'Super' dan meneruskan parameter yang diterima dari konstruktor kelas turunan
        super(nama, harga, rating, type, isFavorite);
    }
    

    //Dikarenakan adanya kelas abstract Menu, maka seluruh kelas turunan harus menggunakan method displayMenuu()

    //@Override adalah sebuah annotation yang digunakan untuk menandai bahwa sebuah metode dalam suatu kelas 
    // Merupakan override dari metode yang sama dalam kelas induknya (superclass)

    @Override
     // Menampilkan menu dan menggunakan Getter agar mendapat nilai dari atribut tersebut
    public void displayMenuu(){
        System.out.println("Drinks Name    : " + getName());
        System.out.println("Drinks Price   : " + getHarga());
        System.out.println("Drinks Rating  : " + getRating());
        System.out.println("Drinks Type    : " + getType());
        System.out.println("Fav's Menu     : " + getIsfavorite());
    }
    // displayMenuu() di dalam kelas Drinks merupakan method untuk mengeprint semua menu Drinks.
    // dan juga merupakan sebuah implementasi Polymorfism dimana nama methodnya sama, namun outputnya berbeda/*/
}