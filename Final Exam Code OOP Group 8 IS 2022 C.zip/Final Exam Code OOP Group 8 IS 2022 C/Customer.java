/*Terdiri atas atribut dalam kelas Customer memiliki tiga jenis informasi yang penting untuk merepresentasikan
 seorang pelanggan dalam sistem antrian. Pertama adalah nameCust, yang merupakan sebuah String yang 
 digunakan untuk menyimpan nama pelanggan. Kemudian, terdapat nomorAntrian, yang merupakan sebuah
  integer yang menyimpan nomor antrian pelanggan. Atribut terakhir adalah isVip, yang merupakan sebuah 
  boolean yang menunjukkan apakah pelanggan tersebut adalah seorang VIP atau tidak. */
  class Customer {
    String nameCust;
    int nomorAntrian;
    boolean isVip;
/*
Terdapat konstruktor dalam kelas Customer berfungsi sebagai metode khusus yang dipanggil saat sebuah objek
Customer baru dibuat. Tujuannya adalah untuk menginisialisasi atribut-atribut objek tersebut dengan 
nilai-nilai yang diberikan sebagai argumen saat pembuatan objek. Dengan kata lain, ketika objek 
Customer dibuat, konstruktor ini akan secara otomatis dijalankan untuk menetapkan nilai awal untuk 
atribut nameCust, nomorAntrian, dan isVip berdasarkan nilai-nilai yang diberikan pada saat pembuatan 
objek. */
    Customer(String nameCust, int nomorAntrian, boolean isVip) {
        this.nameCust = nameCust;
        this.nomorAntrian = nomorAntrian;
        this.isVip = isVip;
    }
/*Terdapat method toString() dalam kelas Customer menghasilkan representasi string dari objek Customer dengan 
menyertakan informasi lengkap tentang pelanggan, seperti nama, nomor antrian, dan status keanggotaan 
VIP-nya. Format string yang dihasilkan adalah "| Nama Pelanggan | Nomor Antrian | VIP |", yang 
memungkinkan pengguna untuk dengan mudah mencetak dan memproses informasi pelanggan dalam berbagai
konteks aplikasi. */
    @Override
    public String toString() {
        return String.format("| %-10s | %-3d | %-3s |", nameCust, nomorAntrian, (isVip ? "Yes" : "No"));
    }
}